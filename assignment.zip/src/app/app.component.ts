import { Component } from '@angular/core';
import { CalendarOptions, Calendar } from '@fullcalendar/core'; // useful for typechecking
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction';
import { bindCallback } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  allMenu = [
    {"header": "Entries", "labels": [
      {"icon": "", "text": "Unclassified Entries"}, 
      {"icon": "", "text": "Classified Entries"}
    ]},
    {"header": "Schedule", "labels": [
      {"icon": "", "text": "Extra Working Day"}, 
      {"icon": "", "text": "Weekly Off"}, 
      {"icon": "", "text": "Holiday"}, 
      {"icon": "", "text": "Leaves"}
    ]},
    {"header": "Achievements", "labels": [
      {"icon": "assets/fire.jpeg", "text": "Longest Streak"}, 
      {"icon": "assets/hourglass.jpeg", "text": "Classified Hours"}
    ]}
  ]
   date = new Date();
   d1 = this.date.getDate();
   m = this.date.getMonth();
   y = this.date.getFullYear();
  title = 'flowace_assignment'

  calendarOptions:  CalendarOptions = {
      plugins: [ dayGridPlugin, interactionPlugin ],
      initialView: 'dayGridMonth',
      
      weekends: true,
      headerToolbar: false,
      events: [
       
        {
          title  : 'event1',
          start  : '2022-07-14'
        },
        {
          title  : 'event2',
          start  : '2022-07-14',
          end    : '2022-07-15'
        },
        {

          start  : '2022-07-18T08:30:00',
          title  : 'First Entry',
          meridiem: 'short'// will make the time show
        },
        {

          start  : '2022-07-18T09:30:00',
          end  : '2022-07-18T21:30:00',
          allDay: false,
          title  : 'Last Entry',
        },
        {
          start  : '2022-07-18T00:00:00',
          title  : 'Worked For 07:00:00',
          className: "hideTime"
          
        },
        {
          title  : 'Holiday',
          start  : '2022-08-14',
          color :'#F6F0FF' ,
          textColor:'rgba(103, 58, 183, 1)'
        },
        {
          title  : 'Independence Day',
          start  : '2022-08-14',
          textColor:'black',
          color:'#F6F0FF'
        },
        {
          title  : 'event3',
          start  : '2022-08-18T12:30:00',
          allDay : false // will make the time show
        },
        {
          title  : 'event3',
          start  : '2022-09-18T12:30:00',
          allDay : false // will make the time show
        },
        {
          title  : 'event3',
          start  : '2022-06-18T12:30:00',
          allDay : false // will make the time show
        },
        {
          title: 'All Day Event',
          start: '2022-04-01'
        },
        {
          title: 'Long Event',
          start: '2022-04-07',
          end: '2022-04-10',
          color: 'purple' 
        },
        
        {
          groupId: '999',
          title: 'Repeating Event',
          start: '2022-04-09T16:00:00'
        },
        {
          groupId: '999',
          title: 'Repeating Event',
          start: '2022-04-16T16:00:00'
        },
        {
          title: 'Conference',
          start: '2022-04-11',
          end: '2022-04-13',
          color: 'purple' // override!
        },
        {
          title: 'Meeting',
          start: '2022-04-12T10:30:00',
          end: '2022-04-12T12:30:00'
        },
        {
          title: 'Lunch',
          start: '2022-04-12T12:00:00'
        },
        {
          title: 'Meeting',
          start: '2022-04-12T14:30:00'
        },
        {
          title: 'Birthday Party',
          start: '2022-04-13T07:00:00'
        },
        {
          title: 'Click for Google',
          url: 'http://google.com/',
          start: '2022-04-28'
        },
        {
          title: 'Weekly Off',
          start: '2022-07-31',
          end: '2022-07-31',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-06-26',
          end: '2022-06-26',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Leave',
          start: '2022-07-04',
          end: '2022-07-04',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-02',
          end: '2022-07-02',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-09',
          end: '2022-07-09',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-16',
          end: '2022-07-16',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-03',
          end:'2022-07-03',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-10',
          end: '2022-07-10',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-17',
          end: '2022-07-17',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-24',
          end: '2022-07-24',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-23',
          end: '2022-07-23',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-07-30',
          end: '2022-07-30',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Weekly Off',
          start: '2022-08-06',
          end: '2022-08-06',
          color: 'rgba(252, 228, 236, 1)' ,// override!
          textColor: 'red' ,
        },
        {
          title: 'Long Event',
          start: '2022-04-07T08:00:00',
          end: '2022-04-10T21:00:00',
          color: 'purple' // override!
        },
      ],
      eventColor: 'white',
      eventTimeFormat:{
        hour : 'numeric',
        minute:'2-digit',
        meridiem:'short'
      },
      eventClick: function(info:any) {
        alert("started on " + info.event.start+'-'+'Event: ' + info.event.title  );
        
      },
      dateClick: function(info:any) {
        alert('Clicked on: ' + info.dateStr);
        alert('Coordinates: ' + info.jsEvent.pageX + ',' + info.jsEvent.pageY);
        alert('Current view: ' + info.view.type);
        // change the day's background color just for fun
        info.dayEl.style.backgroundColor = 'red';
      },
      dayCellDidMount: function(arg:any){
        let dt = arg.date
        if(dt.getDay() == 6 || dt.getDay() == 0) {
          // arg.el.style.backgroundColor = 'rgba(252, 228, 236, 1)'
          arg.el.title='Weekly Off',
          arg.el.textColor='red',
          arg.el.color='rgba(252, 228, 236, 1)'
        }
      },
      eventDidMount: function(args: any){
        let p: HTMLElement = args.el
        if (p.className.indexOf("hideTime") > 0) {
          let cs = p?.children
          if (cs != null) {
            cs.item(1)?.setAttribute("style", "display:none")
          }
        }
      }
    }
    diff = 0
  dateDisplay: any;
  month: any;
  ngOnInit(){
    var date = new Date();
    var d1 = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();
    const monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const d = new Date();
  this.month=monthNames[d.getMonth()];
  
    this.dateDisplay = this.month + ' ' + d.getFullYear().toString();
    console.log('currentDate', this.dateDisplay)
  }
 
updateMonth(next:boolean){
  next ? this.diff++ : this.diff--
  var calendarEl = document.getElementById('calendar')
  if (calendarEl != null) {
    var calendar = new Calendar(calendarEl, this.calendarOptions)
    calendar.render()
    console.log(calendar)

    if (this.diff > 0) {
      for(let i = 0; i < this.diff; i++) {
        calendar.next()
      }
    } else if (this.diff < 0) {
      for (let i = 0; i > this.diff; i--) {
        calendar.prev()
      }
    }
    this.dateDisplay=calendar.currentData.viewTitle
  }
  
 
}
}
